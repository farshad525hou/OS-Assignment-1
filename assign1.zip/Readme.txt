By: Farshad Chowdhury
September 28, 2017
Assignment 1
EECE 4810 Operating Systems and Kernel Design

The puporse of this project was to experiment with processes on a Unix machine. The project covered how to fork process, run code different from its parent, and ensure that a child process does not die before its parent using the wait() function.

Source Files
/parta/pa.c
/partb/pb.c
/partc/pc.c

Executables
PartA
PartB
PartC

To Compile:
Simply use the makefile in the main directory.
Type make into a terminal window in the same directory. 

